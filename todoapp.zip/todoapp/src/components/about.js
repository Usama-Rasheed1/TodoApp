import React from 'react'

export default function About(props){

    return(
        <>
            <div className='container' style={{color: props.mode==='light'? 'black':'white'}}>
                <h1>About US</h1>
                <p> I am A web jabfdjbfaj jdnjfa. adfnandfkldnnlkdnfklan ndj jsdnjsnd.
                </p>

            </div>
        </>
    )
}